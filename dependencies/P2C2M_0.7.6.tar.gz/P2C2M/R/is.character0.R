is.character0 <-
function (instring) {
  # function to check if return is character(0)
  is.character(instring) && length(instring) == 0
}

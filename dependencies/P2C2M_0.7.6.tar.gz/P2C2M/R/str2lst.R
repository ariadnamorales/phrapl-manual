str2lst <-
function (instring) {
  # function for returning a list of letters from a string
  unlist(strsplit(instring, ""))
}

is.integer0 <-
function (instring) {
  # function to check if return is integer(0)
  is.integer(instring) && length(instring) == 0L
}
